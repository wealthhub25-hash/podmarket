-- Creators & customers (one users table; role distinguishes them)
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  display_name TEXT,
  role TEXT NOT NULL DEFAULT 'creator',       -- 'creator' | 'admin'
  telegram_user_id TEXT,
  balance_cents INTEGER NOT NULL DEFAULT 0,   -- running creator royalty balance
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- A design = one creator's artwork, possibly applied to several products
CREATE TABLE IF NOT EXISTS designs (
  id TEXT PRIMARY KEY,
  creator_id TEXT NOT NULL REFERENCES users(id),
  title TEXT NOT NULL,
  image_url TEXT NOT NULL,                    -- hosted image used for print file
  status TEXT NOT NULL DEFAULT 'pending',     -- 'pending' | 'approved' | 'rejected'
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- A product = a design applied to a Printify blueprint (t-shirt, mug, etc.)
CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  design_id TEXT NOT NULL REFERENCES designs(id),
  printify_product_id TEXT,                   -- set once created on Printify
  blueprint_id INTEGER NOT NULL,              -- Printify blueprint (product type)
  print_provider_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  base_cost_cents INTEGER NOT NULL,           -- Printify's cost
  price_cents INTEGER NOT NULL,               -- what customers pay (cost + markup)
  is_enabled INTEGER NOT NULL DEFAULT 0,      -- 0 until admin-approved
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id),
  creator_id TEXT NOT NULL REFERENCES users(id),
  customer_email TEXT NOT NULL,
  shipping_address TEXT NOT NULL,             -- JSON blob
  stripe_session_id TEXT UNIQUE,
  printify_order_id TEXT,
  status TEXT NOT NULL DEFAULT 'awaiting_payment', -- awaiting_payment | paid | submitted | shipped | failed
  tracking_number TEXT,
  amount_cents INTEGER NOT NULL,
  royalty_cents INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_designs_creator ON designs(creator_id);
CREATE INDEX IF NOT EXISTS idx_products_design ON products(design_id);
CREATE INDEX IF NOT EXISTS idx_orders_product ON orders(product_id);
CREATE INDEX IF NOT EXISTS idx_orders_creator ON orders(creator_id);
