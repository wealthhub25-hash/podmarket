import type { Env, User, Design, Product, Order } from "./types";

export const newId = () => crypto.randomUUID();

export async function getUserByEmail(env: Env, email: string): Promise<User | null> {
  const row = await env.DB.prepare("SELECT * FROM users WHERE email = ?").bind(email).first();
  return (row as User) ?? null;
}

export async function getUserById(env: Env, id: string): Promise<User | null> {
  const row = await env.DB.prepare("SELECT * FROM users WHERE id = ?").bind(id).first();
  return (row as User) ?? null;
}

export async function getUserByTelegramId(env: Env, telegramId: string): Promise<User | null> {
  const row = await env.DB.prepare("SELECT * FROM users WHERE telegram_user_id = ?")
    .bind(telegramId)
    .first();
  return (row as User) ?? null;
}

export async function createUser(
  env: Env,
  data: { email: string; password_hash: string; display_name?: string; role?: "creator" | "admin" }
): Promise<User> {
  const id = newId();
  await env.DB.prepare(
    `INSERT INTO users (id, email, password_hash, display_name, role) VALUES (?, ?, ?, ?, ?)`
  )
    .bind(id, data.email, data.password_hash, data.display_name ?? null, data.role ?? "creator")
    .run();
  return (await getUserById(env, id))!;
}

export async function createDesign(
  env: Env,
  data: { creator_id: string; title: string; image_url: string }
): Promise<Design> {
  const id = newId();
  await env.DB.prepare(
    `INSERT INTO designs (id, creator_id, title, image_url) VALUES (?, ?, ?, ?)`
  )
    .bind(id, data.creator_id, data.title, data.image_url)
    .run();
  const row = await env.DB.prepare("SELECT * FROM designs WHERE id = ?").bind(id).first();
  return row as Design;
}

export async function setDesignStatus(env: Env, id: string, status: Design["status"]) {
  await env.DB.prepare("UPDATE designs SET status = ? WHERE id = ?").bind(status, id).run();
}

export async function getDesign(env: Env, id: string): Promise<Design | null> {
  const row = await env.DB.prepare("SELECT * FROM designs WHERE id = ?").bind(id).first();
  return (row as Design) ?? null;
}

export async function createProduct(
  env: Env,
  data: {
    design_id: string;
    blueprint_id: number;
    print_provider_id: number;
    title: string;
    base_cost_cents: number;
    price_cents: number;
    printify_product_id?: string;
  }
): Promise<Product> {
  const id = newId();
  await env.DB.prepare(
    `INSERT INTO products
      (id, design_id, blueprint_id, print_provider_id, title, base_cost_cents, price_cents, printify_product_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  )
    .bind(
      id,
      data.design_id,
      data.blueprint_id,
      data.print_provider_id,
      data.title,
      data.base_cost_cents,
      data.price_cents,
      data.printify_product_id ?? null
    )
    .run();
  const row = await env.DB.prepare("SELECT * FROM products WHERE id = ?").bind(id).first();
  return row as Product;
}

export async function setProductEnabled(env: Env, id: string, enabled: boolean) {
  await env.DB.prepare("UPDATE products SET is_enabled = ? WHERE id = ?")
    .bind(enabled ? 1 : 0, id)
    .run();
}

export async function listEnabledProducts(env: Env): Promise<Product[]> {
  const { results } = await env.DB.prepare(
    "SELECT * FROM products WHERE is_enabled = 1 ORDER BY created_at DESC"
  ).all();
  return (results as Product[]) ?? [];
}

export async function getProduct(env: Env, id: string): Promise<Product | null> {
  const row = await env.DB.prepare("SELECT * FROM products WHERE id = ?").bind(id).first();
  return (row as Product) ?? null;
}

export async function createOrder(
  env: Env,
  data: {
    product_id: string;
    creator_id: string;
    customer_email: string;
    shipping_address: string;
    amount_cents: number;
    royalty_cents: number;
    stripe_session_id: string;
  }
): Promise<Order> {
  const id = newId();
  await env.DB.prepare(
    `INSERT INTO orders
      (id, product_id, creator_id, customer_email, shipping_address, amount_cents, royalty_cents, stripe_session_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  )
    .bind(
      id,
      data.product_id,
      data.creator_id,
      data.customer_email,
      data.shipping_address,
      data.amount_cents,
      data.royalty_cents,
      data.stripe_session_id
    )
    .run();
  const row = await env.DB.prepare("SELECT * FROM orders WHERE id = ?").bind(id).first();
  return row as Order;
}

export async function getOrderBySessionId(env: Env, sessionId: string): Promise<Order | null> {
  const row = await env.DB.prepare("SELECT * FROM orders WHERE stripe_session_id = ?")
    .bind(sessionId)
    .first();
  return (row as Order) ?? null;
}

export async function updateOrderStatus(
  env: Env,
  id: string,
  status: Order["status"],
  extra?: { printify_order_id?: string; tracking_number?: string }
) {
  await env.DB.prepare(
    `UPDATE orders SET status = ?, printify_order_id = COALESCE(?, printify_order_id),
     tracking_number = COALESCE(?, tracking_number) WHERE id = ?`
  )
    .bind(status, extra?.printify_order_id ?? null, extra?.tracking_number ?? null, id)
    .run();
}

export async function creditCreatorBalance(env: Env, creatorId: string, cents: number) {
  await env.DB.prepare("UPDATE users SET balance_cents = balance_cents + ? WHERE id = ?")
    .bind(cents, creatorId)
    .run();
}

export async function recentOrders(env: Env, limit = 10): Promise<Order[]> {
  const { results } = await env.DB.prepare(
    "SELECT * FROM orders ORDER BY created_at DESC LIMIT ?"
  )
    .bind(limit)
    .all();
  return (results as Order[]) ?? [];
}

export async function pendingDesigns(env: Env): Promise<Design[]> {
  const { results } = await env.DB.prepare(
    "SELECT * FROM designs WHERE status = 'pending' ORDER BY created_at ASC"
  ).all();
  return (results as Design[]) ?? [];
}
