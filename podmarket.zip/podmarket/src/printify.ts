import type { Env } from "./types";

const PRINTIFY_BASE = "https://api.printify.com/v1";

function headers(env: Env) {
  return {
    Authorization: `Bearer ${env.PRINTIFY_API_TOKEN}`,
    "Content-Type": "application/json",
  };
}

/** List blueprints (product types: t-shirt, mug, poster, ...). Useful for the creator dashboard dropdown. */
export async function listBlueprints(env: Env) {
  const res = await fetch(`${PRINTIFY_BASE}/catalog/blueprints.json`, { headers: headers(env) });
  if (!res.ok) throw new Error(`Printify listBlueprints failed: ${res.status} ${await res.text()}`);
  return res.json();
}

/** List print providers + variant pricing for a blueprint. */
export async function getBlueprintProviders(env: Env, blueprintId: number) {
  const res = await fetch(`${PRINTIFY_BASE}/catalog/blueprints/${blueprintId}/print_providers.json`, {
    headers: headers(env),
  });
  if (!res.ok) throw new Error(`Printify getBlueprintProviders failed: ${res.status} ${await res.text()}`);
  return res.json();
}

export async function getVariants(env: Env, blueprintId: number, printProviderId: number) {
  const res = await fetch(
    `${PRINTIFY_BASE}/catalog/blueprints/${blueprintId}/print_providers/${printProviderId}/variants.json`,
    { headers: headers(env) }
  );
  if (!res.ok) throw new Error(`Printify getVariants failed: ${res.status} ${await res.text()}`);
  return res.json();
}

/**
 * Upload an image to Printify's media library from a URL (e.g. where you've
 * stored the creator's uploaded design — R2, S3, etc.) so it can be used as
 * print artwork.
 */
export async function uploadImageFromUrl(env: Env, fileName: string, url: string) {
  const res = await fetch(`${PRINTIFY_BASE}/uploads/images.json`, {
    method: "POST",
    headers: headers(env),
    body: JSON.stringify({ file_name: fileName, url }),
  });
  if (!res.ok) throw new Error(`Printify uploadImage failed: ${res.status} ${await res.text()}`);
  return res.json() as Promise<{ id: string }>;
}

/**
 * Create a product on Printify: a design placed on a blueprint/provider
 * combination across all its variants (sizes/colors). Created disabled
 * (visible: false) until admin approval flips it on in your own DB —
 * Printify's own `is_enabled`/`visible` flag can mirror that if you want
 * the raw Printify product hidden from their own storefront tools too.
 */
export async function createProduct(
  env: Env,
  params: {
    title: string;
    description: string;
    blueprintId: number;
    printProviderId: number;
    variantIds: number[];
    printImageId: string;
  }
) {
  const body = {
    title: params.title,
    description: params.description,
    blueprint_id: params.blueprintId,
    print_provider_id: params.printProviderId,
    variants: params.variantIds.map((id) => ({ id, price: 0, is_enabled: true })),
    print_areas: [
      {
        variant_ids: params.variantIds,
        placeholders: [
          {
            position: "front",
            images: [{ id: params.printImageId, x: 0.5, y: 0.5, scale: 1, angle: 0 }],
          },
        ],
      },
    ],
  };
  const res = await fetch(`${PRINTIFY_BASE}/shops/${env.PRINTIFY_SHOP_ID}/products.json`, {
    method: "POST",
    headers: headers(env),
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Printify createProduct failed: ${res.status} ${await res.text()}`);
  return res.json() as Promise<{ id: string }>;
}

/**
 * Submit a real order to Printify once a customer has paid. Printify's print
 * partner takes it from here: manufacture + ship direct to the customer.
 */
export async function submitOrder(
  env: Env,
  params: {
    externalId: string; // your own order id, for idempotency/reconciliation
    lineItems: Array<{ product_id: string; variant_id: number; quantity: number }>;
    shipping: {
      first_name: string;
      last_name: string;
      email: string;
      phone?: string;
      country: string;
      region?: string;
      address1: string;
      address2?: string;
      city: string;
      zip: string;
    };
    shippingMethod?: number; // 1 = standard, provider-dependent
  }
) {
  const body = {
    external_id: params.externalId,
    line_items: params.lineItems,
    shipping_method: params.shippingMethod ?? 1,
    send_shipping_notification: true,
    address_to: params.shipping,
  };
  const res = await fetch(`${PRINTIFY_BASE}/shops/${env.PRINTIFY_SHOP_ID}/orders.json`, {
    method: "POST",
    headers: headers(env),
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Printify submitOrder failed: ${res.status} ${await res.text()}`);
  return res.json() as Promise<{ id: string }>;
}

export async function getOrder(env: Env, printifyOrderId: string) {
  const res = await fetch(`${PRINTIFY_BASE}/shops/${env.PRINTIFY_SHOP_ID}/orders/${printifyOrderId}.json`, {
    headers: headers(env),
  });
  if (!res.ok) throw new Error(`Printify getOrder failed: ${res.status} ${await res.text()}`);
  return res.json();
}

// TODO: Printify webhooks don't use a standard HMAC signature scheme the way
// Stripe does as of writing — verify against Printify's current docs
// (https://developers.printify.com/#webhooks) before trusting payloads in
// src/index.ts's /api/webhooks/printify route. At minimum, treat the shop_id
// in the payload as untrusted until confirmed.
