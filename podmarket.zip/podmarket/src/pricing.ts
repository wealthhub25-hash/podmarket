import type { Env } from "./types";

/**
 * Given Printify's base cost for a product, compute the customer-facing
 * price and the creator's royalty cut.
 *
 * price_cents  = base_cost_cents + markup_cents
 * royalty      = markup_cents * CREATOR_ROYALTY_PCT / 100
 * your margin  = markup_cents - royalty
 */
export function computePricing(env: Env, baseCostCents: number, customMarkupCents?: number) {
  const markup = customMarkupCents ?? parseInt(env.DEFAULT_MARKUP_CENTS, 10) || 1500;
  const royaltyPct = parseInt(env.CREATOR_ROYALTY_PCT, 10) || 50;
  const priceCents = baseCostCents + markup;
  const royaltyCents = Math.round((markup * royaltyPct) / 100);
  return { priceCents, royaltyCents, markup };
}
