import type { Env } from "./types";

const STRIPE_API = "https://api.stripe.com/v1";

function formEncode(obj: Record<string, string>): string {
  return Object.entries(obj)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join("&");
}

export async function createCheckoutSession(
  env: Env,
  params: {
    productTitle: string;
    priceCents: number;
    successUrl: string;
    cancelUrl: string;
    metadata: Record<string, string>; // product_id, creator_id — read back in the webhook
  }
) {
  const body: Record<string, string> = {
    mode: "payment",
    success_url: params.successUrl,
    cancel_url: params.cancelUrl,
    "line_items[0][price_data][currency]": "usd",
    "line_items[0][price_data][product_data][name]": params.productTitle,
    "line_items[0][price_data][unit_amount]": String(params.priceCents),
    "line_items[0][quantity]": "1",
    "shipping_address_collection[allowed_countries][0]": "US",
    "shipping_address_collection[allowed_countries][1]": "CA",
    "shipping_address_collection[allowed_countries][2]": "GB",
  };
  for (const [k, v] of Object.entries(params.metadata)) {
    body[`metadata[${k}]`] = v;
  }

  const res = await fetch(`${STRIPE_API}/checkout/sessions`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${env.STRIPE_SECRET_KEY}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: formEncode(body),
  });
  if (!res.ok) throw new Error(`Stripe createCheckoutSession failed: ${res.status} ${await res.text()}`);
  return res.json() as Promise<{ id: string; url: string }>;
}

export async function getCheckoutSession(env: Env, sessionId: string) {
  const res = await fetch(
    `${STRIPE_API}/checkout/sessions/${sessionId}?expand[]=customer_details`,
    { headers: { Authorization: `Bearer ${env.STRIPE_SECRET_KEY}` } }
  );
  if (!res.ok) throw new Error(`Stripe getCheckoutSession failed: ${res.status} ${await res.text()}`);
  return res.json();
}

/**
 * Verify a Stripe webhook signature manually (Stripe-Signature header),
 * since the full stripe-node SDK isn't a drop-in fit for Workers. Implements
 * Stripe's documented v1 signature scheme:
 * https://stripe.com/docs/webhooks/signatures#verify-manually
 */
export async function verifyStripeSignature(
  payload: string,
  sigHeader: string,
  secret: string,
  toleranceSeconds = 300
): Promise<boolean> {
  const parts = Object.fromEntries(
    sigHeader.split(",").map((kv) => {
      const [k, v] = kv.split("=");
      return [k, v];
    })
  );
  const timestamp = parts["t"];
  const sig = parts["v1"];
  if (!timestamp || !sig) return false;

  const now = Math.floor(Date.now() / 1000);
  if (Math.abs(now - parseInt(timestamp, 10)) > toleranceSeconds) return false;

  const signedPayload = `${timestamp}.${payload}`;
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const macBuf = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(signedPayload));
  const expected = Array.from(new Uint8Array(macBuf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  // Constant-time-ish compare
  if (expected.length !== sig.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) diff |= expected.charCodeAt(i) ^ sig.charCodeAt(i);
  return diff === 0;
}
