import { Hono } from "hono";
import type { Env } from "./types";
import {
  createUser,
  getUserByEmail,
  getUserById,
  createDesign,
  getDesign,
  createProduct,
  listEnabledProducts,
  getProduct,
  createOrder,
  getOrderBySessionId,
  updateOrderStatus,
  creditCreatorBalance,
} from "./db";
import { hashPassword, verifyPassword, signJwt, requireAuth } from "./auth";
import { computePricing } from "./pricing";
import * as printify from "./printify";
import * as stripe from "./stripe";
import { handleTelegramUpdate, notifyNewOrder, notifyNewDesign } from "./telegram";

const app = new Hono<{ Bindings: Env }>();

// ---------- Auth ----------

app.post("/api/signup", async (c) => {
  const { email, password, display_name } = await c.req.json();
  if (!email || !password) return c.json({ error: "email and password required" }, 400);

  const existing = await getUserByEmail(c.env, email);
  if (existing) return c.json({ error: "account already exists" }, 409);

  const password_hash = await hashPassword(password);
  const user = await createUser(c.env, { email, password_hash, display_name });
  const token = await signJwt({ sub: user.id, role: user.role }, c.env.JWT_SECRET);
  return c.json({ token, user: { id: user.id, email: user.email, role: user.role } });
});

app.post("/api/login", async (c) => {
  const { email, password } = await c.req.json();
  const user = await getUserByEmail(c.env, email);
  if (!user || !(await verifyPassword(password, user.password_hash))) {
    return c.json({ error: "invalid credentials" }, 401);
  }
  const token = await signJwt({ sub: user.id, role: user.role }, c.env.JWT_SECRET);
  return c.json({ token, user: { id: user.id, email: user.email, role: user.role } });
});

app.get("/api/me", async (c) => {
  const payload = await requireAuth(c, c.env);
  if (!payload) return c.json({ error: "unauthorized" }, 401);
  const user = await getUserById(c.env, payload.sub as string);
  if (!user) return c.json({ error: "not found" }, 404);
  return c.json({
    id: user.id,
    email: user.email,
    display_name: user.display_name,
    role: user.role,
    balance_cents: user.balance_cents,
  });
});

// ---------- Printify catalog passthrough (for the design/product builder UI) ----------

app.get("/api/catalog/blueprints", async (c) => {
  return c.json(await printify.listBlueprints(c.env));
});

app.get("/api/catalog/blueprints/:id/providers", async (c) => {
  return c.json(await printify.getBlueprintProviders(c.env, Number(c.req.param("id"))));
});

app.get("/api/catalog/blueprints/:id/providers/:providerId/variants", async (c) => {
  return c.json(
    await printify.getVariants(c.env, Number(c.req.param("id")), Number(c.req.param("providerId")))
  );
});

// ---------- Designs (creator uploads) ----------

app.post("/api/designs", async (c) => {
  const payload = await requireAuth(c, c.env);
  if (!payload) return c.json({ error: "unauthorized" }, 401);

  const {
    title,
    image_url, // must already be a publicly reachable URL (e.g. uploaded to R2/S3 first)
    blueprint_id,
    print_provider_id,
    variant_ids,
    markup_cents,
  } = await c.req.json();

  if (!title || !image_url || !blueprint_id || !print_provider_id || !variant_ids?.length) {
    return c.json({ error: "title, image_url, blueprint_id, print_provider_id, variant_ids required" }, 400);
  }

  const creator = await getUserById(c.env, payload.sub as string);
  if (!creator) return c.json({ error: "unauthorized" }, 401);

  const design = await createDesign(c.env, { creator_id: creator.id, title, image_url });

  // Push the artwork + product to Printify
  const uploaded = await printify.uploadImageFromUrl(c.env, `${design.id}.png`, image_url);
  const printifyProduct = await printify.createProduct(c.env, {
    title,
    description: `${title} — designed by ${creator.display_name ?? creator.email}`,
    blueprintId: blueprint_id,
    printProviderId: print_provider_id,
    variantIds: variant_ids,
    printImageId: uploaded.id,
  });

  // We need a base cost to price against — fetch variant pricing from Printify.
  const variantsResp: any = await printify.getVariants(c.env, blueprint_id, print_provider_id);
  const firstVariant = variantsResp.variants?.find((v: any) => variant_ids.includes(v.id));
  const baseCostCents = firstVariant?.cost ?? 1000; // fallback if Printify doesn't return cost here

  const { priceCents } = computePricing(c.env, baseCostCents, markup_cents);

  const product = await createProduct(c.env, {
    design_id: design.id,
    blueprint_id,
    print_provider_id,
    title,
    base_cost_cents: baseCostCents,
    price_cents: priceCents,
    printify_product_id: printifyProduct.id,
  });

  await notifyNewDesign(c.env, design.id, title, creator.email);

  return c.json({ design, product });
});

// ---------- Storefront (public) ----------

app.get("/api/products", async (c) => {
  const products = await listEnabledProducts(c.env);
  return c.json(products);
});

app.get("/api/products/:id", async (c) => {
  const product = await getProduct(c.env, c.req.param("id"));
  if (!product || !product.is_enabled) return c.json({ error: "not found" }, 404);
  return c.json(product);
});

// ---------- Checkout ----------

app.post("/api/checkout", async (c) => {
  const { product_id, origin } = await c.req.json();
  const product = await getProduct(c.env, product_id);
  if (!product || !product.is_enabled) return c.json({ error: "product not available" }, 404);

  const design = await getDesign(c.env, product.design_id);
  if (!design) return c.json({ error: "design not found" }, 404);

  const session = await stripe.createCheckoutSession(c.env, {
    productTitle: product.title,
    priceCents: product.price_cents,
    successUrl: `${origin}/success.html?session_id={CHECKOUT_SESSION_ID}`,
    cancelUrl: `${origin}/`,
    metadata: { product_id: product.id, creator_id: design.creator_id },
  });

  return c.json({ checkout_url: session.url });
});

// ---------- Webhooks ----------

app.post("/api/webhooks/stripe", async (c) => {
  const sig = c.req.header("Stripe-Signature");
  const rawBody = await c.req.text();
  if (!sig || !(await stripe.verifyStripeSignature(rawBody, sig, c.env.STRIPE_WEBHOOK_SECRET))) {
    return c.text("invalid signature", 400);
  }

  const event = JSON.parse(rawBody);
  if (event.type !== "checkout.session.completed") return c.text("ignored", 200);

  const session = event.data.object;
  const productId = session.metadata.product_id;
  const creatorId = session.metadata.creator_id;
  const product = await getProduct(c.env, productId);
  if (!product) return c.text("product missing", 200);

  const { royaltyCents } = computePricing(c.env, product.base_cost_cents);

  const order = await createOrder(c.env, {
    product_id: productId,
    creator_id: creatorId,
    customer_email: session.customer_details?.email ?? "unknown",
    shipping_address: JSON.stringify(session.shipping_details ?? session.customer_details ?? {}),
    amount_cents: session.amount_total,
    royalty_cents: royaltyCents,
    stripe_session_id: session.id,
  });

  await updateOrderStatus(c.env, order.id, "paid");
  await creditCreatorBalance(c.env, creatorId, royaltyCents);
  await notifyNewOrder(c.env, order, product.title);

  // Submit the real production order to Printify
  try {
    const shippingDetails = session.shipping_details ?? session.customer_details;
    const [first_name, ...rest] = (shippingDetails?.name ?? "Customer").split(" ");
    const printifyOrder = await printify.submitOrder(c.env, {
      externalId: order.id,
      lineItems: [
        {
          product_id: product.printify_product_id!,
          variant_id: 0, // TODO: track the specific variant purchased (size/color) through checkout
          quantity: 1,
        },
      ],
      shipping: {
        first_name,
        last_name: rest.join(" ") || "—",
        email: order.customer_email,
        country: shippingDetails?.address?.country ?? "US",
        address1: shippingDetails?.address?.line1 ?? "",
        address2: shippingDetails?.address?.line2 ?? undefined,
        city: shippingDetails?.address?.city ?? "",
        region: shippingDetails?.address?.state ?? "",
        zip: shippingDetails?.address?.postal_code ?? "",
      },
    });
    await updateOrderStatus(c.env, order.id, "submitted", { printify_order_id: printifyOrder.id });
  } catch (err) {
    // Payment succeeded but fulfillment submission failed — flag for manual handling.
    await updateOrderStatus(c.env, order.id, "failed");
    console.error("Printify order submission failed:", err);
  }

  return c.text("ok", 200);
});

app.post("/api/webhooks/printify", async (c) => {
  // See TODO in src/printify.ts re: signature verification.
  const event = await c.req.json();
  // Expect something like { type: 'order:shipment:created', resource: { id, tracking_number } }
  if (event?.resource?.id) {
    const { results } = await c.env.DB.prepare("SELECT id FROM orders WHERE printify_order_id = ?")
      .bind(event.resource.id)
      .all();
    const orderRow = (results as any[])?.[0];
    if (orderRow) {
      await updateOrderStatus(c.env, orderRow.id, "shipped", {
        tracking_number: event.resource.tracking_number,
      });
    }
  }
  return c.text("ok", 200);
});

// ---------- Telegram bot webhook ----------

app.post("/api/telegram/webhook", async (c) => {
  const update = await c.req.json();
  await handleTelegramUpdate(c.env, update);
  return c.text("ok", 200);
});

export default app;
