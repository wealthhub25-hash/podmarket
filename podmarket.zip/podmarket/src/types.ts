export type Env = {
  DB: D1Database;
  ASSETS: Fetcher;

  PRINTIFY_API_TOKEN: string;
  PRINTIFY_SHOP_ID: string;
  STRIPE_SECRET_KEY: string;
  STRIPE_WEBHOOK_SECRET: string;
  TELEGRAM_BOT_TOKEN: string;
  TELEGRAM_ADMIN_IDS: string; // comma-separated
  JWT_SECRET: string;

  STOREFRONT_NAME: string;
  DEFAULT_MARKUP_CENTS: string;
  CREATOR_ROYALTY_PCT: string;
};

export type User = {
  id: string;
  email: string;
  password_hash: string;
  display_name: string | null;
  role: "creator" | "admin";
  telegram_user_id: string | null;
  balance_cents: number;
  created_at: string;
};

export type Design = {
  id: string;
  creator_id: string;
  title: string;
  image_url: string;
  status: "pending" | "approved" | "rejected";
  created_at: string;
};

export type Product = {
  id: string;
  design_id: string;
  printify_product_id: string | null;
  blueprint_id: number;
  print_provider_id: number;
  title: string;
  base_cost_cents: number;
  price_cents: number;
  is_enabled: number;
  created_at: string;
};

export type Order = {
  id: string;
  product_id: string;
  creator_id: string;
  customer_email: string;
  shipping_address: string;
  stripe_session_id: string | null;
  printify_order_id: string | null;
  status: "awaiting_payment" | "paid" | "submitted" | "shipped" | "failed";
  tracking_number: string | null;
  amount_cents: number;
  royalty_cents: number;
  created_at: string;
};
