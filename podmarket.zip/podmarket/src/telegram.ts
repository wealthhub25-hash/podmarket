import type { Env, Order } from "./types";
import {
  getUserByTelegramId,
  getUserById,
  pendingDesigns,
  recentOrders,
  getDesign,
  setDesignStatus,
  setProductEnabled,
} from "./db";

const TG_API = (token: string) => `https://api.telegram.org/bot${token}`;

export function adminIds(env: Env): string[] {
  return env.TELEGRAM_ADMIN_IDS.split(",").map((s) => s.trim()).filter(Boolean);
}

async function tgSend(env: Env, chatId: string | number, text: string) {
  await fetch(`${TG_API(env.TELEGRAM_BOT_TOKEN)}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text, parse_mode: "Markdown" }),
  });
}

/** Notify every admin chat — call this from order/design creation flows. */
export async function notifyAdmins(env: Env, text: string) {
  for (const id of adminIds(env)) {
    await tgSend(env, id, text);
  }
}

export async function notifyNewOrder(env: Env, order: Order, productTitle: string) {
  await notifyAdmins(
    env,
    `🛒 *New order*\n${productTitle}\n$${(order.amount_cents / 100).toFixed(2)} — ${order.customer_email}\nOrder: \`${order.id}\``
  );
}

export async function notifyNewDesign(env: Env, designId: string, title: string, creatorEmail: string) {
  await notifyAdmins(
    env,
    `🎨 *New design pending approval*\n"${title}" by ${creatorEmail}\nApprove with: \`/approve ${designId}\`\nReject with: \`/reject ${designId}\``
  );
}

/** Main entry point, called from the /api/telegram/webhook route in index.ts */
export async function handleTelegramUpdate(env: Env, update: any) {
  const message = update.message;
  if (!message?.text) return;

  const chatId: number = message.chat.id;
  const fromId: string = String(message.from.id);
  const text: string = message.text.trim();
  const [cmd, ...args] = text.split(/\s+/);

  const isAdmin = adminIds(env).includes(fromId);

  switch (cmd) {
    case "/start":
      await tgSend(
        env,
        chatId,
        `Welcome to ${env.STOREFRONT_NAME}'s bot.\n\nIf you're a creator, link your account with:\n\`/link your@email.com\`\n\nThen try \`/earnings\` and \`/mydesigns\`.`
      );
      return;

    case "/link": {
      const email = args[0];
      if (!email) return tgSend(env, chatId, "Usage: /link your@email.com");
      // NOTE: for production, send a confirmation code to the email instead
      // of trusting the chat message outright.
      const { getUserByEmail } = await import("./db");
      const user = await getUserByEmail(env, email);
      if (!user) return tgSend(env, chatId, "No account found with that email.");
      await env.DB.prepare("UPDATE users SET telegram_user_id = ? WHERE id = ?").bind(fromId, user.id).run();
      return tgSend(env, chatId, `Linked! You're now talking to the bot as ${email}.`);
    }

    case "/earnings": {
      const user = await getUserByTelegramId(env, fromId);
      if (!user) return tgSend(env, chatId, "Link your account first with /link your@email.com");
      return tgSend(env, chatId, `💰 Balance: $${(user.balance_cents / 100).toFixed(2)}`);
    }

    case "/mydesigns": {
      const user = await getUserByTelegramId(env, fromId);
      if (!user) return tgSend(env, chatId, "Link your account first with /link your@email.com");
      const { results } = await env.DB.prepare(
        "SELECT title, status FROM designs WHERE creator_id = ? ORDER BY created_at DESC LIMIT 15"
      )
        .bind(user.id)
        .all();
      if (!results?.length) return tgSend(env, chatId, "No designs yet.");
      const lines = (results as any[]).map((d) => `• ${d.title} — ${d.status}`);
      return tgSend(env, chatId, lines.join("\n"));
    }

    // ---- Admin-only commands below ----
    case "/pending": {
      if (!isAdmin) return tgSend(env, chatId, "Admins only.");
      const designs = await pendingDesigns(env);
      if (!designs.length) return tgSend(env, chatId, "No designs awaiting approval.");
      const lines = designs.map((d) => `• ${d.title} — \`${d.id}\``);
      return tgSend(env, chatId, `*Pending designs:*\n${lines.join("\n")}`);
    }

    case "/approve": {
      if (!isAdmin) return tgSend(env, chatId, "Admins only.");
      const designId = args[0];
      if (!designId) return tgSend(env, chatId, "Usage: /approve <design_id>");
      await setDesignStatus(env, designId, "approved");
      // Enable every product built from this design
      await env.DB.prepare("UPDATE products SET is_enabled = 1 WHERE design_id = ?").bind(designId).run();
      return tgSend(env, chatId, `Approved ✅ design ${designId} — its products are now live.`);
    }

    case "/reject": {
      if (!isAdmin) return tgSend(env, chatId, "Admins only.");
      const designId = args[0];
      if (!designId) return tgSend(env, chatId, "Usage: /reject <design_id>");
      await setDesignStatus(env, designId, "rejected");
      return tgSend(env, chatId, `Rejected ❌ design ${designId}.`);
    }

    case "/orders": {
      if (!isAdmin) return tgSend(env, chatId, "Admins only.");
      const orders = await recentOrders(env, 10);
      if (!orders.length) return tgSend(env, chatId, "No orders yet.");
      const lines = orders.map(
        (o) => `• ${o.status} — $${(o.amount_cents / 100).toFixed(2)} — ${o.customer_email}`
      );
      return tgSend(env, chatId, `*Last ${orders.length} orders:*\n${lines.join("\n")}`);
    }

    case "/stats": {
      if (!isAdmin) return tgSend(env, chatId, "Admins only.");
      const totals = await env.DB.prepare(
        `SELECT COUNT(*) as n, COALESCE(SUM(amount_cents),0) as revenue,
                COALESCE(SUM(amount_cents - royalty_cents),0) as margin
         FROM orders WHERE status != 'awaiting_payment'`
      ).first();
      const t = totals as any;
      return tgSend(
        env,
        chatId,
        `📊 *Stats*\nPaid orders: ${t.n}\nRevenue: $${(t.revenue / 100).toFixed(2)}\nYour margin: $${(
          t.margin / 100
        ).toFixed(2)}`
      );
    }

    default:
      return tgSend(
        env,
        chatId,
        "Unknown command. Try /earnings, /mydesigns" + (isAdmin ? ", /pending, /orders, /stats, /approve, /reject" : ".")
      );
  }
}
