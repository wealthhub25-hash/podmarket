# PodMarket — Print-on-Demand Marketplace (Cloudflare Workers + Printify + Telegram)

A Redbubble-style marketplace: creators sign up, upload designs, you push them onto
Printify products, customers buy through your storefront, Printify prints & ships,
you keep the margin and pay creators a royalty. A Telegram bot handles admin
management (approve designs, view orders, stats) and creator self-service
(check earnings, see design status).

## Stack
- **Cloudflare Workers** (Hono framework) — API + static frontend, deployed to `*.workers.dev`
- **Cloudflare D1** — SQLite database (orders, users, designs, products)
- **Printify API** — product creation + order fulfillment
- **Stripe** — checkout + payment confirmation
- **Telegram Bot API** — admin + creator management via webhook

## 1. Prerequisites (you said you'll handle these yourself)
- A Cloudflare account + `wrangler` CLI (`npm i -g wrangler`)
- A Printify account → API token: https://printify.com/app/account/api
- A Printify **Shop ID** (`GET https://api.printify.com/v1/shops.json` with your token)
- A Stripe account → secret key + webhook signing secret
- A Telegram bot → token from **@BotFather**, and your own numeric Telegram user ID
  (message **@userinfobot** to get it) for admin-only commands

## 2. Install & configure

```bash
cd podmarket
npm install
wrangler login

# Create the D1 database
wrangler d1 create podmarket-db
# ^ copy the returned database_id into wrangler.toml

# Apply schema
wrangler d1 execute podmarket-db --file=./migrations/0001_init.sql --remote

# Set secrets (never put these in wrangler.toml)
wrangler secret put PRINTIFY_API_TOKEN
wrangler secret put PRINTIFY_SHOP_ID
wrangler secret put STRIPE_SECRET_KEY
wrangler secret put STRIPE_WEBHOOK_SECRET
wrangler secret put TELEGRAM_BOT_TOKEN
wrangler secret put TELEGRAM_ADMIN_IDS      # comma-separated Telegram user IDs
wrangler secret put JWT_SECRET              # any long random string
```

## 3. Deploy

```bash
wrangler deploy
```

This gives you a URL like `https://podmarket.<your-subdomain>.workers.dev`.

## 4. Wire up webhooks (one-time, after deploy)

**Stripe** — in the Stripe dashboard, add a webhook endpoint pointing to:
`https://<your-worker-url>/api/webhooks/stripe`
Subscribe to `checkout.session.completed`.

**Telegram** — register your webhook by visiting this URL once in a browser
(replace both placeholders):
```
https://api.telegram.org/bot<TELEGRAM_BOT_TOKEN>/setWebhook?url=https://<your-worker-url>/api/telegram/webhook
```

## 5. How the flow works

1. Creator signs up on the storefront (`/signup`) → gets a JWT.
2. Creator uploads a design image + picks a Printify blueprint (t-shirt, mug, etc.)
   via `POST /api/designs` → backend calls Printify to create the product listing.
3. Customer browses `/` → adds to cart → `POST /api/checkout` creates a Stripe
   Checkout Session with your markup already applied.
4. On successful payment, Stripe fires the webhook → backend creates the real
   order on Printify (`POST /api/webhooks/stripe`) → Printify's print partner
   manufactures & ships directly to the customer.
5. Printify sends order status updates — point a Printify webhook at
   `/api/webhooks/printify` to sync shipped/tracking status.
6. The Telegram bot pings the admin chat on every new order and every new
   design submission awaiting approval. Creators can DM the bot `/earnings`
   to see their running balance.

## 6. Project layout

```
podmarket/
  wrangler.toml          # Workers config — bind D1 here
  migrations/0001_init.sql
  src/
    index.ts             # Hono app, route registration
    db.ts                # D1 query helpers
    auth.ts              # JWT signup/login for creators
    printify.ts           # Printify API client
    stripe.ts             # Stripe checkout + webhook verification
    telegram.ts           # Telegram bot command router + webhook handler
    pricing.ts            # margin/royalty calculation
  public/
    index.html            # storefront (browse + buy)
    dashboard.html         # creator dashboard (upload design, see earnings)
    app.css / app.js
```

## 7. Pricing & payout logic (edit `src/pricing.ts`)
Default: you set a `markup_cents` per product on top of Printify's cost price.
Of that markup, `CREATOR_ROYALTY_PCT` (default 50%) goes to the creator's
running balance in D1; the rest is your margin. Payouts to creators aren't
automated here (that needs Stripe Connect or manual bank transfer) — the bot's
`/earnings` command just reports the balance so you can pay out manually or
wire up Connect later.

## Notes / things to harden before going live
- Design moderation: products are created as `is_enabled: false` in Printify
  until an admin approves via the bot (`/approve <design_id>`), to avoid
  copyright/IP exposure.
- Add rate limiting on `/api/designs` and signup to prevent abuse.
- Swap the simple JWT auth for something more robust (e.g. hashed passwords
  are included, but consider WebAuthn/OAuth for production).
- Printify webhook signature verification is stubbed — see TODO in
  `src/printify.ts`.
