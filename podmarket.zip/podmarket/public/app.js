const API = ""; // same-origin; Worker serves both API and static files

function getToken() {
  return localStorage.getItem("pm_token");
}
function setToken(t) {
  localStorage.setItem("pm_token", t);
}
function clearToken() {
  localStorage.removeItem("pm_token");
}
function authHeaders() {
  const t = getToken();
  return t ? { Authorization: `Bearer ${t}` } : {};
}

async function api(path, opts = {}) {
  const res = await fetch(API + path, {
    ...opts,
    headers: {
      "Content-Type": "application/json",
      ...authHeaders(),
      ...(opts.headers || {}),
    },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

// ---------- Storefront ----------

async function loadProducts() {
  const grid = document.getElementById("product-grid");
  if (!grid) return;
  try {
    const products = await api("/api/products");
    if (!products.length) {
      grid.outerHTML = '<p class="empty">No products live yet — check back soon.</p>';
      return;
    }
    grid.innerHTML = products
      .map(
        (p) => `
      <div class="card">
        <div class="thumb"><img src="${p.title ? "" : ""}" alt="${p.title}" onerror="this.style.display='none'"/></div>
        <div class="title">${p.title}</div>
        <div class="price">$${(p.price_cents / 100).toFixed(2)}</div>
        <button data-product-id="${p.id}" class="buy-btn">Buy</button>
      </div>`
      )
      .join("");
    grid.querySelectorAll(".buy-btn").forEach((btn) => {
      btn.addEventListener("click", () => buyProduct(btn.dataset.productId));
    });
  } catch (err) {
    grid.outerHTML = `<p class="empty">Couldn't load products: ${err.message}</p>`;
  }
}

async function buyProduct(productId) {
  try {
    const { checkout_url } = await api("/api/checkout", {
      method: "POST",
      body: JSON.stringify({ product_id: productId, origin: window.location.origin }),
    });
    window.location.href = checkout_url;
  } catch (err) {
    alert("Checkout failed: " + err.message);
  }
}

// ---------- Auth forms ----------

function wireAuthForm(formId, endpoint) {
  const form = document.getElementById(formId);
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const msg = form.querySelector(".msg");
    const data = Object.fromEntries(new FormData(form).entries());
    try {
      const result = await api(endpoint, { method: "POST", body: JSON.stringify(data) });
      setToken(result.token);
      window.location.href = "/dashboard.html";
    } catch (err) {
      if (msg) {
        msg.textContent = err.message;
        msg.className = "msg show error";
      }
    }
  });
}

// ---------- Creator dashboard ----------

async function loadDashboard() {
  const who = document.getElementById("who");
  if (!who) return;
  if (!getToken()) {
    window.location.href = "/login.html";
    return;
  }
  try {
    const me = await api("/api/me");
    who.textContent = me.display_name || me.email;
    document.getElementById("balance").textContent = `$${(me.balance_cents / 100).toFixed(2)}`;
  } catch {
    clearToken();
    window.location.href = "/login.html";
  }
}

function wireLogout() {
  const btn = document.getElementById("logout-btn");
  if (btn) btn.addEventListener("click", () => {
    clearToken();
    window.location.href = "/";
  });
}

function wireDesignUpload() {
  const form = document.getElementById("design-form");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const msg = form.querySelector(".msg");
    const data = Object.fromEntries(new FormData(form).entries());
    data.variant_ids = data.variant_ids.split(",").map((s) => parseInt(s.trim(), 10));
    data.blueprint_id = parseInt(data.blueprint_id, 10);
    data.print_provider_id = parseInt(data.print_provider_id, 10);
    if (data.markup_cents) data.markup_cents = parseInt(data.markup_cents, 10);
    else delete data.markup_cents;

    try {
      await api("/api/designs", { method: "POST", body: JSON.stringify(data) });
      msg.textContent = "Submitted! It'll go live once an admin approves it.";
      msg.className = "msg show ok";
      form.reset();
    } catch (err) {
      msg.textContent = err.message;
      msg.className = "msg show error";
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  loadProducts();
  wireAuthForm("signup-form", "/api/signup");
  wireAuthForm("login-form", "/api/login");
  loadDashboard();
  wireLogout();
  wireDesignUpload();
});
